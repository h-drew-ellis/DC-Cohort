//Create an app which determines whether the number is even or odd.
function oddEven(num) {
    let i = num; {
        if (i % 2 === 0) {
            console.log("even number");
        } else {
            console.log("odd number");
        }
    }
}

oddEven();