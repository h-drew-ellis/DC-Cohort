
console.log("hello world")

console.log(posts)