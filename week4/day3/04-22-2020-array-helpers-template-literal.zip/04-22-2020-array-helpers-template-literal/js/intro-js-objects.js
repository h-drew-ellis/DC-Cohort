

let user = {name: "John Doe"}

// console.log(posts)

for(let index = 0; index < comments.length; index++) {
    
    let comment = comments[index]

    console.log(comment.id)  
    console.log(comment.email) 
    console.log(comment.name)
}





/*
// using the default JS class called Object 
let car = {make: "Honda", model: "Accord"}
car.drive = function() {
    console.log("driving...")
}
car.drive() 

let car2 = {make: "Toyota"}
car2.drive() 

console.log(car)

//let car = new Object() 
*/

