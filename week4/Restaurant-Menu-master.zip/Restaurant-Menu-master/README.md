# Restaurant-Menu

JavaScript object assignment

Create a page which displays all the dishes on a web page. The listing will include the following:

Title

Description

Price

The page should also have an option to FILTER the dishes by course:

Starters

Entrees

Desserts

- Make sure the website is responsive on mobile devices.

Example Layout Shown Below:
