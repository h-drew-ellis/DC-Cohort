let x = new XMLHttpRequest;
let moviesList = document.getElementById("moviesList")
x.addEventListener("load", function() {

    let batman = JSON.parse(this.responseText)

    let movie = batman.Search.map((b) => {
        if (b.Type == "movie") {
            return `<li style="list-style-type:none; width 300px">
                <img src="${b.Poster}" style="width: 125px"></img>
                <label>${b.Title}</label>
                </li>`
        }
    })
    moviesList.innerHTML = movie.join("")
})



x.open("GET", "http://www.omdbapi.com/?s=batman&apikey=e71db758");
x.send()