i = input("please provide me a word to check. : ")
x = i[::-1]

if i == x:
    print("Yes this is a Palindrome!")
else:
    print("nope, this is a new... made up word, maybe")